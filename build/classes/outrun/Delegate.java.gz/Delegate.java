/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package outrun;

import org.newdawn.slick.SlickException;

/**
 *
 * @author lukas_000
 * 
 * Basic interface for delegate methods.
 */
public interface Delegate {
	public void run() throws SlickException;
}
