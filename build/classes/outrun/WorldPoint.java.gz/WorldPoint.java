/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package outrun;

/**
 *
 * @author lukas_000
 */
public class WorldPoint {
	float cam_x;
	float cam_y;
	float cam_z;
	float screen_x;
	float screen_y;
	float screen_z;
	float screen_w;
	float screen_scale;
	float world_x;
	float world_y;
	float world_z;
}
